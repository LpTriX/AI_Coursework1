# OUC Coursework 1 - Group 38 review package

This is a review draft. Member IDs and HWU usernames are confirmed. The video URL and final review are pending.
Do not upload this archive as a completed submission.

## Sudoku

From the Sudoku directory, with Python 3.9+:

    python3 solver.py puzzles/p2.txt --stats
    python3 gui.py
    python3 -m unittest -v test_solver test_gui

The solver uses the standard library. The GUI requires a working Tk install.
See Sudoku/README.md for input formats and interface behaviour.

## PDDL

From this archive's root:

    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements-planning.txt
    .venv/bin/python -m pyperplan -s gbf -H hff "PDDL/PartA&B/domain.pddl" "PDDL/PartA&B/mission1.pddl"
    .venv/bin/python -m pyperplan -s gbf -H hff "PDDL/PartA&B/domain.pddl" "PDDL/PartA&B/mission2.pddl"
    .venv/bin/python -m pyperplan -s gbf -H hff PDDL/PartC/domain-ext.pddl PDDL/PartC/mission3.pddl

The PDDL directory retains the required starter paths and contains five files.
Evidence and Sudoku/results retain actual plans and measured data.
The optional independent validation utilities are run from the full Git checkout;
the planner commands above work directly from this extracted package.

