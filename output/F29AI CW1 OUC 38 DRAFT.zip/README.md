# OUC Coursework 1 - Group 38 review package

This is a review draft. Member IDs and HWU usernames are confirmed. The video URL and final review are pending.
Do not upload this archive as a completed submission.

## Sudoku

From the Sudoku directory, with Python 3.9+:

    python3 solver.py puzzles/p2.txt --stats
    python3 gui.py
    python3 -m unittest -v test_solver test_gui

The solver uses the standard library. The GUI requires a working Tk install.
See Sudoku/README.md for input formats and interface behaviour.

## PDDL

From this archive's root:

    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements-planning.txt
    .venv/bin/python tools/validate_extension.py --output validation-output

The PDDL directory retains the required starter paths and contains five files.
Evidence and Sudoku/results retain actual plans and measured data.

